##Ce programme charge le modèle morphosyntaxique généré en utilisant Keras Tensorflow. Il effectue ensuite l'étiquetage morphosyntaxique
## Sur de nouvelles phrases.

from sklearn.feature_extraction import DictVectorizer
from sklearn.preprocessing import LabelEncoder
from keras.models import load_model
import numpy as np
from pickle import load

aḍris=[]
amenzu=0

uḍfiren=[]
uzwiren=[]

Asenqeḍ=['...',',',';','?','!',':','"','(',')','*','_','.','[',']','{','}','«','»','+','=','“','”']
for i in open("affixescolles.txt",encoding='utf-8'):
    a=i
    a=a.replace("\ufeff","")
    a=a.replace("\n","")
    if (a[len(a)-1]=="-"):

     uzwiren.append(str(a))
    else:
       uḍfiren.append(str(a))

def tokenize_awal(awal,uḍfiren,uzwiren):
    a=''
    amurfim=awal[0:awal.find('-')+1]

    awal_yebḍan=''
    if (amurfim in uzwiren):
        awal=awal[awal.find('-')+1:len(awal)]
        awal_yebḍan=awal_yebḍan+' '+amurfim
        while awal.find('-')>=0:

            amurfim=awal[0:awal.find('-')+1]
            awal=awal[awal.find('-')+1:len(awal)]
            awal_yebḍan=awal_yebḍan+' '+amurfim
        awal_yebḍan=awal_yebḍan+' '+awal
    else:
        amurfim=awal[0:awal.find('-')]
        awal_yebḍan=awal_yebḍan+' '+amurfim
        awal=awal[awal.find('-')+1:len(awal)]
        while awal.find('-')>=0:

           amurfim=awal[0:awal.find('-')]
           awal_yebḍan=awal_yebḍan+' '+'-'+amurfim
           awal=awal[awal.find('-')+1:len(awal)]
    if ('-'+awal in uḍfiren):
         awal_yebḍan=awal_yebḍan+' '+'-'+awal
    else:
         awal_yebḍan=awal_yebḍan



    return awal_yebḍan


def tokenize(sentence,uḍfiren,uzwiren):
       for i in Asenqeḍ:
        sentence=sentence.replace(i, " "+i+" ")
       a=sentence.split()
       tafyirt1=""
       for i in a: #mots
        if(i.find('-')<0):
            tafyirt1=tafyirt1+' '+i
        else:
            awals=tokenize_awal(i,uḍfiren,uzwiren)
            tafyirt1=tafyirt1+' '+awals
       tafyirt1=tafyirt1.strip()
       return tafyirt1




def add_basic_features(sentence_terms, index):
    term = sentence_terms[index]
    return {
        'nb_terms': len(sentence_terms),
        'term': term,
        'is_first': index == 0,
        'is_last': index == len(sentence_terms) - 1,
        'is_capitalized': term[0].upper() == term[0],
        'is_all_caps': term.upper() == term,
        'is_all_lower': term.lower() == term,
        'is_numeric': sentence_terms[index].isdigit(),
        'prev_word': '' if index == 0 else sentence_terms[index - 1],
        'prev2_word': '' if index == 1 else sentence_terms[index - 2],
        'next_word': '' if index == len(sentence_terms) - 1 else sentence_terms[index + 1],
        'prefix-1': sentence_terms[index][0],
        'prefix-2': sentence_terms[index][:2],
        'prefix-3': sentence_terms[index][:3],
        'prefix-4': sentence_terms[index][:4],
        'prefix-5': sentence_terms[index][:5],
        'suffix-1': sentence_terms[index][-1],
        'suffix-2': sentence_terms[index][-2:],
        'suffix-3': sentence_terms[index][-3:],
        'suffix-4': sentence_terms[index][-4:],

    }

def transform_to_dataset(sentences):
    X = []

    for sentence in sentences:
        for index, word in enumerate(sentence) :
            X.append(add_basic_features(sentence, index))
    return X

tifyar=[
'Ad as-tent-id-awiɣ.',
'Ay abrid ttun medden.',
'Yemɣi-d leḥcic di later-ik.',
'Aɛudiw n baba d jeddi, rniɣ rrekba n deffir!',
'Wwiɣ-d 4582 n tfunasin.',
'Axxam, ibennu ɣef llsas.',
'Llsas-nneɣ nekni d ayen nnan d wayen gan yimezwura-nneɣ.',
'D win i aɣ-ilaq ad d-nejmeɛ ass-a.',
'Awerrat iḥerzen ayen i as-d-yekkan sɣur lwaldin-is, yelha; win yernan s ayen i as-d-yeǧǧa baba-s, yif-it.',
'Win yebɣan, yettnadi amek; win yugin, yeqqar kan ulamek.',
'Am win yettnadin tilkin deg uqerru uferḍas.',
'Am win yettrebbin ibki, la taduṭ la ayefki.',
'Yal wa yettṣerrif seg wayen yesɛa.'

]
sentences=[]
for i in tifyar:
    tafyirt=tokenize(i,uḍfiren,uzwiren)
    tafyirt=tafyirt.split()
    print (tafyirt)
    sentences.append(tafyirt)

print (sentences)


X_train = transform_to_dataset(sentences)
# Fit our DictVectorizer with our set of features
dict_vectorizer = DictVectorizer(sparse=False)
dict_vectorizer.fit(X_train)

# Convert dict features to vectors
X_train = dict_vectorizer.transform(X_train)


# load model the kerras model
loaded_model = load(open('model_keras.clf', 'rb'))
#load the input dim
for l in loaded_model.layers:
    inputs= l.input_shape[1]
    break
#add remaining dim for the sentences to be taged
a=np.zeros((X_train.shape[0], inputs-X_train.shape[1]))
X_train=np.concatenate((X_train, a),axis=1)
# make prediction
predictions = loaded_model.predict_classes(X_train,verbose=1)

#lod the tag labels
label_encoder = LabelEncoder()
label_encoder = load(open('label_encoder.pkl', 'rb'))

#print words and theur tags

words=[]
for i in sentences:
    for j in i:
        words.append(j)
print(words)

print(label_encoder.inverse_transform(predictions))