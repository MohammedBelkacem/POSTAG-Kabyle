﻿## Ce programme permet de faire la semgementation morphosyntaxique et l'étiquetage morphosyntaxique d'un fichier texte contenant
##des phrases de langue kabyle basé sur l'lagorithme ap. Il génère deux fichies, l'un contenant les phrases segmentées
##et l'autre contenant les phrases étiquetés.
from sklearn_crfsuite import CRF
aḍris=[]
amenzu=0

uḍfiren=[]
uzwiren=[]

Asenqeḍ=['...',',',';','?','!',':','"','(',')','*','_','.','[',']','{','}','«','»','+','=','“','”']
for i in open("affixescolles.txt",encoding='utf-8'):
    a=i
    a=a.replace("\ufeff","")
    a=a.replace("\n","")
    if (a[len(a)-1]=="-"):

     uzwiren.append(str(a))
    else:
       uḍfiren.append(str(a))

def tokenize_awal(awal,uḍfiren,uzwiren):
    a=''
    amurfim=awal[0:awal.find('-')+1]

    awal_yebḍan=''
    if (amurfim in uzwiren):
        awal=awal[awal.find('-')+1:len(awal)]
        awal_yebḍan=awal_yebḍan+' '+amurfim
        while awal.find('-')>=0:

            amurfim=awal[0:awal.find('-')+1]
            awal=awal[awal.find('-')+1:len(awal)]
            awal_yebḍan=awal_yebḍan+' '+amurfim
        awal_yebḍan=awal_yebḍan+' '+awal
    else:
        amurfim=awal[0:awal.find('-')]
        awal_yebḍan=awal_yebḍan+' '+amurfim
        awal=awal[awal.find('-')+1:len(awal)]
        while awal.find('-')>=0:

           amurfim=awal[0:awal.find('-')]
           awal_yebḍan=awal_yebḍan+' '+'-'+amurfim
           awal=awal[awal.find('-')+1:len(awal)]
    if ('-'+awal in uḍfiren):
         awal_yebḍan=awal_yebḍan+' '+'-'+awal
    else:
         awal_yebḍan=awal_yebḍan



    return awal_yebḍan


def tokenize(sentence,uḍfiren,uzwiren):
       a=sentence.split()
       tafyirt1=""
       for i in a: #mots
        if(i.find('-')<0):
            tafyirt1=tafyirt1+' '+i
        else:
            awals=tokenize_awal(i,uḍfiren,uzwiren)
            tafyirt1=tafyirt1+' '+awals
       tafyirt1=tafyirt1.strip()
       return tafyirt1


def features(sentence, index):
       return {
        'word': sentence[index],    # Awal s timmad-is
        'is_first': index == 0,     # Ma yezga-d deg tazwar n tefyirt
        'is_last': index == len(sentence) - 1, # Ma yezgma-d deg taggar n tefyirt
        'is_capitalized': sentence[index][0].upper() == sentence[index][0], # MA ibeddu s usekkil meqqren
        'is_all_caps': sentence[index].upper() == sentence[index], # Ma yura meṛṛa s usekkil meqqren
        'is_all_lower': sentence[index].lower() == sentence[index], # ma yura meṛṛa s usekkil meẓẓiyen
        'prefix-1': sentence[index][0],  #1 usekkil uzwir
        'prefix-2': sentence[index][:2], #2 isekkilen uzwiren
        'prefix-3': sentence[index][:3], #3 isekkilen uzwiren
        'prefix-4': sentence[index][:4], #4 isekkilen uzwiren
        'prefix-5': sentence[index][:5], #5 isekkilen uzwiren tettecmumuḥenḍ (aoriste intensif)
        'suffix-1': sentence[index][-1],  #1 usekkil uḍfir
        'suffix-2': sentence[index][-2:], #2 isekkilen uḍfiren
        'suffix-3': sentence[index][-3:], #3 isekkilen uḍfiren
        'suffix-4': sentence[index][-4:], #4 isekkilen uḍfiren
        'suffix-5': sentence[index][-5:], #5 isekkilen uḍfiren
        'prev_word': '' if index == 0 else sentence[index - 1], #awal uzwir
        'prev1_word': '' if index == 1 else sentence[index - 2], #awal uzwir
        'next_word': '' if index == len(sentence) - 1 else sentence[index + 1], #awal uḍfir
        'is_numeric': sentence[index].isdigit(),  #ma yegber kan izwilen
        'capitals_inside': sentence[index][1:].lower() != sentence[index][1:] #ma yegber asekkil meqqren daxel-is
    }


model = CRF()


def pos_tag(sentence,model):
    try:
     sentence_features = [features(sentence, index) for index in range(len(sentence))]
    except:
        return (sentence)
    return list(zip(sentence, model.predict([sentence_features])[0]))


from joblib import dump, load
#dump(model, 'lodel.joblib')
#print(metrics.flat_accuracy_score(y_test, y_pred))
clf = load('model-ap.joblib')

f= open("tokenized_text.txt","w+",encoding='utf-8')
h= open("tagged_text.txt","w+",encoding='utf-8')
g=open("brut_text.txt",encoding='utf-8')
for adur in g:
    #print (adur)
    for i in Asenqeḍ:

        if i=='.':
            adur=adur.replace(i,' '+i+' ')
        else:
            adur=adur.replace(i,' '+i+' ')
    adur=adur.replace("\ufeff","")

    ligne=tokenize(adur,uḍfiren,uzwiren)

    ligne=ligne.replace("  "," ")
    ligne=ligne
    izirig=""
    izirig1=ligne

    f.write(izirig1+'\n')
    #print (izirig1.split(" "))
    xx=pos_tag(izirig1.split(" "),clf)
    for u in xx:
        try:
         yy=u[0]+'/'+u[1]
         izirig=izirig+yy+" "
        except:
            print (izirig1+"$$$$$")
            f.close()
            g.close()
            h.close()
            exit()

    #print(xx)
    h.write(izirig+'\n')

    #t.sleep(0.5)
    #print ("tafyirt: ",ligne, "beṭṭu: ",izirig1, "acraḍ :",izirig)

f.close()
g.close()
h.close()
print ("Yedda akken iwata!! Aḍris yettwacreḍ. ")