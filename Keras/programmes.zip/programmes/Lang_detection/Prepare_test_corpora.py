#Ce programme permet d'extraire 10 phrase de chaque fichier de langue à partir de la phrase numéro 5000
#du corpus téléchargé pour former un seul corpus mélangé pour tester la classification

limit=10
from_=5000
tutlayin=['kab','eng','fra','ita','eus','cat','por','spa','deu','nld','swe','est','srp','tur','hun']
i=0
afaylu_yemmden= open("Brut.csv","w+",encoding='utf-8')
for tutlayt in tutlayin:
    i=0
    afaylu_zeddigen=open(tutlayt+"_sentences.txt",encoding='utf-8')
    for sentence in afaylu_zeddigen:
        #print (sentence)
        if i>5000:
         afaylu_yemmden.write(sentence.replace("\n","").replace('\r',"")+'\r')
        i=i+1
        if limit!=0 and i>=limit+from_:
            afaylu_zeddigen.close()
            break

    afaylu_zeddigen.close()
afaylu_yemmden.close()
