#ce programme permet d'extraire uniquement les phrases du corpus téléchargé sans les autres informations contenues dans ces fichiers

tutlayin=['kab','eng','fra','ita','eus','cat','por','spa','deu','nld','swe','est','srp','tur','hun']

for tutlayt in tutlayin:
    afaylu_arewway= open(tutlayt+"_sentences.tsv",encoding='utf-8')
    afaylu_zeddigen=open(tutlayt+"_sentences.txt","w+",encoding='utf-8')

    for adur in afaylu_arewway:
     adur=adur.replace("\ufeff","")
     azalen = adur.split("\t")
     afaylu_zeddigen.write(azalen[2])
    afaylu_arewway.close()
    afaylu_zeddigen.close()
