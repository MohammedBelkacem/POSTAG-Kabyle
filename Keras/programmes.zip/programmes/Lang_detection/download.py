## Ce programme permet de télécharger des corpus de phrases à partie de la plateforme Tatoeba.
## Pour ajouter une langue, insérer son code iso 639-3 dans le tableau ci-dessous
import wget
#wali tutlayin yellan deg tatoeba akken ad tessadre tigrummiwin n yisefka. Rnu tangalt n tutlayt-a ddaw-a

tutlayin=['kab','eng','fra','ita','eus','cat','por','spa','deu','nld','swe','est','srp','tur','hun']#tinglin iso 639-3
for i in tutlayin:
    wget.download('https://downloads.tatoeba.org/exports/per_language/'+str(i)+'/'+str(i)+'_sentences.tsv.bz2')