# Ce programme permet d'extraire 1000 phrase de chaque fichier de langue . Il servira à entrainer l'algorithme et générer le modele de langue
limit=1000
tutlayin=['kab','eng','fra','ita','eus','cat','por','spa','deu','nld','swe','est','srp','tur','hun']
i=0
afaylu_yemmden= open("LanguageDetection.csv","w+",encoding='utf-8')
afaylu_yemmden.write("sentence"+'\t'+"language"+'\r')
for tutlayt in tutlayin:
    i=0
    afaylu_zeddigen=open(tutlayt+"_sentences.txt",encoding='utf-8')
    for sentence in afaylu_zeddigen:
        afaylu_yemmden.write(sentence.replace("\n","")+'\t'+tutlayt+'\r')
        i=i+1
        if limit!=0 and i>=limit:
            afaylu_zeddigen.close()
            break
    afaylu_zeddigen.close()
afaylu_yemmden.close()
